﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZADANIE_3
{
    class Copier
    {
    }
}
